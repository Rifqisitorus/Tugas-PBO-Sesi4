/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfisme_bank;

/**
 *
 * @author Sayid
 */
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan nama bank asal: ");
        String bankAsal = input.nextLine();

        System.out.print("Masukkan jumlah uang yang ingin ditransfer: ");
        int jumlah = input.nextInt();
        input.nextLine();

        System.out.print("Masukkan nomor rekening tujuan: ");
        String rekeningTujuan = input.nextLine();

        System.out.print("Masukkan nama bank tujuan: ");
        String bankTujuan = input.nextLine();

        System.out.print("Tambahkan berita (opsional, tekan Enter jika tidak ada): ");
        String berita = input.nextLine();

        Bank bank;
        if (bankAsal.equalsIgnoreCase("BNI")) {
            bank = new BankBNI();
        } else if (bankAsal.equalsIgnoreCase("BCA")) {
            bank = new BankBCA();
        } else {
            bank = new Bank();
        }

        if (berita.isEmpty()) {
            bank.transferUang(jumlah, rekeningTujuan, bankAsal, bankTujuan);
        } else {
            bank.transferUang(jumlah, rekeningTujuan, bankAsal, bankTujuan, berita);
        }

        bank.sukuBunga();
        input.close();
    }
}




