/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfisme_bank;

/**
 *
 * @author Sayid
 */
class Bank {
    void transferUang(int jumlah, String rekeningTujuan, String bankAsal, String bankTujuan) {
        int biaya = hitungBiayaTransfer(bankAsal, bankTujuan);
        int totalDikirim = jumlah - biaya;
        System.out.println("Transfer Rp" + jumlah + " ke rekening " + rekeningTujuan + " di bank " + bankTujuan);
        System.out.println("Biaya transfer: Rp" + biaya);
        System.out.println("Total yang diterima penerima: Rp" + totalDikirim);
    }

    void transferUang(int jumlah, String rekeningTujuan, String bankAsal, String bankTujuan, String berita) {
        int biaya = hitungBiayaTransfer(bankAsal, bankTujuan);
        int totalDikirim = jumlah - biaya;
        System.out.println("Transfer Rp" + jumlah + " ke rekening " + rekeningTujuan + " di bank " + bankTujuan);
        System.out.println("Berita: " + berita);
        System.out.println("Biaya transfer: Rp" + biaya);
        System.out.println("Total yang diterima penerima: Rp" + totalDikirim);
    }

    void sukuBunga() {
        System.out.println("Suku Bunga standar adalah 3%");
    }

    int hitungBiayaTransfer(String bankAsal, String bankTujuan) {
        if (bankAsal.equalsIgnoreCase(bankTujuan)) {
            return 0;
        }
        return 6500;
    }
}




